;<?php return; ?>
[SQL]
host = 127.0.0.1
user = root
password =
dbname = db_toko